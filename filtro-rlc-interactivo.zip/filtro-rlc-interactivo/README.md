# Filtro RLC interactivo

Simulador interactivo de un circuito RLC en serie ($L = 0.5\text{ H}$, $C = 200\text{ \mu F}$, salida en el condensador) con respuesta al escalón de 12 V, respuesta en frecuencia logarítmica, tabla de atenuación y demostración sonora en tiempo real.

## Estructura del proyecto

```text
filtro-rlc-interactivo/
├── index.html          # Estructura HTML semántica
├── css/
│   └── styles.css      # Estilos, tema claro/oscuro y diseño adaptable
├── js/
│   ├── physics.js      # Modelo matemático del circuito RLC (V_C, ganancia, métricas y régimen)
│   ├── charts.js       # Gráficos SVG de respuesta al escalón y en frecuencia
│   ├── audio.js        # Web Audio API: síntesis, grabación, carga y filtro pasa-bajas IIR
│   └── main.js         # Controlador de eventos e interfaz
└── README.md           # Esta guía
```

## Cómo usarlo

1. Descomprime el archivo `.zip`.
2. Abre `index.html` con doble clic en cualquier navegador moderno (Chrome, Edge, Firefox o Safari).
   - Los scripts están organizados sin módulos ES (`type="module"`) a propósito para que funcionen directamente al abrir el archivo local (`file://`) sin errores de CORS ni servidores extra.
3. Si deseas grabar tu voz desde el micrófono, acepta el permiso cuando el navegador lo solicite (o abre la carpeta con un servidor local, por ejemplo `python -m http.server 8000`).
