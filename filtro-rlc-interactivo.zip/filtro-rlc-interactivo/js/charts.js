/**
 * charts.js
 * Renderizado SVG de las dos pantallas del osciloscopio:
 *   1. Respuesta al escalón de 12 V
 *   2. Respuesta en frecuencia (escala log-log)
 */
(function (global) {
  "use strict";

  const RLC = (global.RLC = global.RLC || {});
  const { fn, vc, gain } = RLC.physics;

  function drawAxes(W, H, m) {
    return `<rect x="${m.l}" y="${m.t}" width="${W - m.l - m.r}" height="${H - m.t - m.b}" fill="none" stroke="var(--line)"/>`;
  }

  /**
   * Dibuja la respuesta temporal al escalón de 12 V en el elemento SVG dado.
   * @param {SVGElement} svgEl
   * @param {number} R Resistencia actual en ohmios.
   */
  function drawStepResponse(svgEl, R) {
    const W = svgEl.clientWidth;
    const H = svgEl.clientHeight;
    if (!W) return;

    const m = { l: 40, r: 10, t: 10, b: 28 };
    const T = 0.6;
    const Y = 22;
    const x = (t) => m.l + (t / T) * (W - m.l - m.r);
    const y = (v) => H - m.b - (v / Y) * (H - m.t - m.b);

    let markup = drawAxes(W, H, m);

    // Rejilla horizontal (voltaje)
    for (let v = 0; v <= 20; v += 5) {
      markup += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(v)}" y2="${y(v)}" stroke="var(--grid)"/>`;
      markup += `<text x="${m.l - 6}" y="${y(v) + 4}" text-anchor="end">${v}</text>`;
    }

    // Etiquetas de tiempo
    const stepT = W < 520 ? 0.2 : 0.1;
    for (let t = 0; t <= 0.6001; t += stepT) {
      const anchor = t > 0.55 ? "end" : "middle";
      markup += `<text x="${x(t)}" y="${H - 8}" text-anchor="${anchor}">${t.toFixed(1)} s</text>`;
    }

    // Línea de referencia E = 12 V
    markup += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(12)}" y2="${y(12)}" stroke="var(--slate)" stroke-dasharray="5 4"/>`;
    markup += `<text x="${W - m.r - 4}" y="${y(12) - 6}" text-anchor="end">E = 12 V</text>`;

    // Curva de comparación (Butterworth, R = 70.7 Ω)
    if (R !== 70.7) {
      let refPath = "";
      for (let i = 0; i <= 400; i++) {
        const t = (i / 400) * T;
        refPath += `${i ? "L" : "M"}${x(t).toFixed(1)} ${y(vc(t, 70.7)).toFixed(1)}`;
      }
      markup += `<path d="${refPath}" fill="none" stroke="var(--slate)" stroke-width="1.5" opacity=".55"/>`;
    }

    // Curva principal para la R seleccionada
    let mainPath = "";
    for (let i = 0; i <= 600; i++) {
      const t = (i / 600) * T;
      mainPath += `${i ? "L" : "M"}${x(t).toFixed(1)} ${y(Math.min(Y, vc(t, R))).toFixed(1)}`;
    }
    markup += `<path d="${mainPath}" fill="none" stroke="var(--amb)" stroke-width="3"/>`;

    svgEl.innerHTML = markup;
  }

  /**
   * Dibuja la respuesta en frecuencia |V_C|/|E| en escala logarítmica.
   * @param {SVGElement} svgEl
   * @param {number} R Resistencia actual en ohmios.
   */
  function drawFrequencyResponse(svgEl, R) {
    const W = svgEl.clientWidth;
    const H = svgEl.clientHeight;
    if (!W) return;

    const m = { l: 46, r: 10, t: 10, b: 28 };
    const lx = [0, 3.3];
    const ly = [-4, 1];
    const x = (f) => m.l + ((Math.log10(f) - lx[0]) / (lx[1] - lx[0])) * (W - m.l - m.r);
    const y = (g) => H - m.b - ((Math.log10(g) - ly[0]) / (ly[1] - ly[0])) * (H - m.t - m.b);

    let markup = drawAxes(W, H, m);

    // Rejilla logarítmica de ganancia
    for (let e = -4; e <= 1; e++) {
      const val = 10 ** e;
      const label = e >= 0 ? val : val.toFixed(-e);
      markup += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(val)}" y2="${y(val)}" stroke="var(--grid)"/>`;
      markup += `<text x="${m.l - 6}" y="${y(val) + 4}" text-anchor="end">${label}</text>`;
    }

    // Etiquetas de frecuencia
    for (const f of [1, 10, 100, 1000]) {
      const anchor = f === 1 ? "start" : "middle";
      markup += `<text x="${x(f)}" y="${H - 8}" text-anchor="${anchor}">${f} Hz</text>`;
    }

    // Frecuencia natural f_n
    markup += `<line x1="${x(fn)}" x2="${x(fn)}" y1="${m.t}" y2="${H - m.b}" stroke="var(--slate)" stroke-dasharray="2 4"/>`;
    markup += `<text x="${x(fn) + 5}" y="${m.t + 14}">f<tspan dy="3" font-size="10">n</tspan><tspan dy="-3"> = 15.9 Hz</tspan></text>`;

    // Nivel de -3 dB (0.707)
    markup += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(0.707)}" y2="${y(0.707)}" stroke="var(--slate)" stroke-dasharray="5 4" opacity=".7"/>`;

    // Curva de ganancia
    let path = "";
    for (let i = 0; i <= 500; i++) {
      const f = 10 ** (lx[0] + (i / 500) * (lx[1] - lx[0]));
      const gClamped = Math.max(1e-4, Math.min(10, gain(f, R)));
      path += `${i ? "L" : "M"}${x(f).toFixed(1)} ${y(gClamped).toFixed(1)}`;
    }
    markup += `<path d="${path}" fill="none" stroke="var(--amb)" stroke-width="3"/>`;

    // Puntos destacados de referencia (5 Hz, 50 Hz, 500 Hz)
    for (const f of [5, 50, 500]) {
      markup += `<circle cx="${x(f)}" cy="${y(gain(f, R))}" r="4.5" fill="var(--ink)"/>`;
    }

    svgEl.innerHTML = markup;
  }

  RLC.charts = {
    drawStepResponse,
    drawFrequencyResponse,
  };
})(window);
