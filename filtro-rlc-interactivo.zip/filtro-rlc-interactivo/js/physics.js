/**
 * physics.js
 * Modelo matemático exacto del circuito RLC en serie (salida en el condensador).
 * Ecuación diferencial: L * Q'' + R * Q' + Q / C = E(t)
 */
(function (global) {
  "use strict";

  const RLC = (global.RLC = global.RLC || {});

  const L = 0.5;                                 // Inductancia (H)
  const C = 200e-6;                              // Capacitancia (F)
  const E0 = 12;                                 // Voltaje del escalón (V)
  const Rcr = 2 * Math.sqrt(L / C);              // Resistencia crítica (100 Ω)
  const fn = 1 / (2 * Math.PI * Math.sqrt(L * C)); // Frecuencia natural (~15.92 Hz)
  const PRESETS = [10, 50, 70.7, 100, 200];

  /**
   * Voltaje del condensador V_C(t) ante un escalón de voltaje E0.
   * @param {number} t Tiempo en segundos.
   * @param {number} R Resistencia en ohmios.
   * @returns {number} Voltaje en voltios.
   */
  function vc(t, R) {
    const a = R / (2 * L);
    const d = R * R - (4 * L) / C;

    // Caso críticamente amortiguado
    if (Math.abs(d) < 1e-6) {
      return E0 - E0 * Math.exp(-a * t) * (1 + a * t);
    }

    // Caso subamortiguado
    if (d < 0) {
      const b = Math.sqrt(-d) / (2 * L);
      return E0 - E0 * Math.exp(-a * t) * (Math.cos(b * t) + (a / b) * Math.sin(b * t));
    }

    // Caso sobreamortiguado
    const r1 = (-R + Math.sqrt(d)) / (2 * L);
    const r2 = (-R - Math.sqrt(d)) / (2 * L);
    return (
      E0 +
      ((E0 * r2) / (r1 - r2)) * Math.exp(r1 * t) -
      ((E0 * r1) / (r1 - r2)) * Math.exp(r2 * t)
    );
  }

  /**
   * Magnitud de la ganancia en frecuencia |V_C| / |E|.
   * @param {number} f Frecuencia en Hz.
   * @param {number} R Resistencia en ohmios.
   * @returns {number} Ganancia lineal.
   */
  function gain(f, R) {
    const w = 2 * Math.PI * f;
    return 1 / Math.sqrt((1 - L * C * w * w) ** 2 + (R * C * w) ** 2);
  }

  /**
   * Calcula sobreimpulso (%), tiempo de establecimiento (2 %) y pico de ganancia.
   * @param {number} R Resistencia en ohmios.
   */
  function stats(R) {
    let mx = 0;
    let last = 0;

    for (let i = 0; i <= 15000; i++) {
      const t = i * 1e-4;
      const v = vc(t, R);
      if (v > mx) mx = v;
      if (Math.abs(v - E0) > 0.24) last = t;
    }

    let pk = 0;
    for (let i = 0; i <= 2000; i++) {
      const g = gain(10 ** (-1 + i * 0.002), R);
      if (g > pk) pk = g;
    }

    return {
      os: Math.max(0, ((mx - E0) / E0) * 100),
      ts: last,
      pk,
      mx,
    };
  }

  /**
   * Describe el régimen de amortiguamiento para la resistencia actual.
   * @param {number} R Resistencia en ohmios.
   * @returns {[string, string]} [Título del régimen, explicación].
   */
  function regimen(R) {
    const z = R / Rcr;

    if (Math.abs(z - 1) < 0.004) {
      return [
        "Críticamente amortiguado",
        "El más rápido que llega a 12 V sin pasarse. Como filtro ya empieza a recortar los graves.",
      ];
    }

    if (z < 1) {
      if (z < 0.5) {
        return [
          "Subamortiguado: rebota mucho",
          "Se pasa de 12 V y oscila. Como filtro, amplifica las señales cerca de 15.9 Hz (resonancia).",
        ];
      }
      if (z < 0.69) {
        return [
          "Subamortiguado: rebota poco",
          "Todavía se pasa un poco y conserva un pequeño pico de resonancia.",
        ];
      }
      if (z < 0.72) {
        return [
          "Subamortiguado, ζ ≈ 0.707 (Butterworth)",
          "Nuestra recomendación: banda de paso plana sin pico, apenas 4 % de rebote y estable en 0.06 s.",
        ];
      }
      return [
        "Subamortiguado, casi crítico",
        "Rebote mínimo y sin pico de ganancia, pero ya atenúa un poco los graves.",
      ];
    }

    return [
      "Sobreamortiguado: lento, sin oscilar",
      "No rebota, pero tarda más y atenúa los graves que queremos conservar.",
    ];
  }

  RLC.physics = {
    L,
    C,
    E0,
    Rcr,
    fn,
    PRESETS,
    vc,
    gain,
    stats,
    regimen,
  };
})(window);
