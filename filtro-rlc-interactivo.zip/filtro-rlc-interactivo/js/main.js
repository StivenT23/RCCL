/**
 * main.js
 * Controlador principal de la interfaz: enlaza controles, métricas, tabla, gráficos y audio.
 */
(function (global) {
  "use strict";

  const RLC = global.RLC;
  const { Rcr, fn, PRESETS, gain, stats, regimen } = RLC.physics;
  const { drawStepResponse, drawFrequencyResponse } = RLC.charts;
  const audio = RLC.audio;

  const $ = (id) => document.getElementById(id);

  const TABLE_FREQS = [
    [5, "5 Hz"],
    [fn, "15.9 Hz"],
    [50, "50 Hz"],
    [500, "500 Hz"],
  ];

  function renderTable(R) {
    $("tb").innerHTML = TABLE_FREQS.map(([f, label]) => {
      const g = gain(f, R);
      const pct = g * 100;
      const gainText = g < 0.01 ? g.toFixed(4) : g.toFixed(3);
      const pctText = pct < 1 ? pct.toFixed(2) : pct.toFixed(1);
      const barWidth = Math.min(80, pct * 0.8).toFixed(1);

      return `
        <tr>
          <td>${label}</td>
          <td>${gainText}</td>
          <td><span class="bar" style="width:${barWidth}px"></span>${pctText} %</td>
        </tr>
      `;
    }).join("");
  }

  function update() {
    const R = +$("r").value;
    $("rv").textContent = R.toFixed(1);

    const st = stats(R);
    const [regimeTitle, regimeWhy] = regimen(R);

    $("reg").textContent = regimeTitle;
    $("why").textContent = regimeWhy;
    $("z").textContent = (R / Rcr).toFixed(2);
    $("os").textContent = st.os < 0.05 ? "0 %" : `${st.os.toFixed(1)} %`;
    $("ts").textContent = `${st.ts.toFixed(3)} s`;

    const pkEl = $("pk");
    pkEl.textContent = `×${st.pk.toFixed(2)}`;
    pkEl.style.color = st.pk > 1.01 ? "var(--bad)" : "var(--ok)";

    for (const btn of document.querySelectorAll("#pre button")) {
      btn.classList.toggle("on", +btn.dataset.r === R);
    }

    renderTable(R);
    drawStepResponse($("s1"), R);
    drawFrequencyResponse($("s2"), R);
  }

  function init() {
    // 1. Generar botones de valores preestablecidos
    $("pre").innerHTML = PRESETS.map(
      (r) => `<button type="button" data-r="${r}">${r} Ω</button>`
    ).join("");

    $("pre").addEventListener("click", (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      $("r").value = btn.dataset.r;
      update();
    });

    // 2. Deslizador de resistencia
    $("r").addEventListener("input", update);

    // 3. Redibujar gráficos cuando cambie el tamaño del contenedor
    const resizeObserver = new ResizeObserver(() => update());
    resizeObserver.observe($("s1"));

    // 4. Controles del módulo de audio
    const setSourceName = (text) => {
      $("srcn").textContent = text;
    };
    const setStatus = (text) => {
      $("an").textContent = text;
    };

    $("rec").addEventListener("click", () => {
      audio.recordVoice({
        buttonEl: $("rec"),
        onSourceName: setSourceName,
        onStatus: setStatus,
      });
    });

    $("file").addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        audio.loadBlob(file, file.name, {
          onSourceName: setSourceName,
          onStatus: setStatus,
        });
      }
    });

    $("syn").addEventListener("click", () => {
      audio.resetToSynth({
        onSourceName: setSourceName,
        onStatus: setStatus,
      });
    });

    $("p0").addEventListener("click", () => {
      audio.play({
        filtered: false,
        R: +$("r").value,
        onStatus: setStatus,
      });
    });

    $("p1").addEventListener("click", () => {
      audio.play({
        filtered: true,
        R: +$("r").value,
        onStatus: setStatus,
      });
    });

    // Renderizado inicial
    update();
  }

  init();
})(window);
