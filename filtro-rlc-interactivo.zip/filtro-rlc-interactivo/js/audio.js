/**
 * audio.js
 * Motor de audio basado en Web Audio API:
 *   - Señal sintetizada de prueba (110 Hz + 3000 Hz)
 *   - Grabación desde micrófono (3 s) y carga de archivos de audio
 *   - Filtrado pasa-bajas RLC (transformación bilineal con corte en 400 Hz)
 */
(function (global) {
  "use strict";

  const RLC = (global.RLC = global.RLC || {});
  const { L, Rcr, fn, gain } = RLC.physics;

  let ctx = null;
  let currentSource = null;
  let userAudio = null;

  function getAudioContext() {
    if (!ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      ctx = new AudioCtx();
    }
    return ctx;
  }

  /**
   * Genera 2.5 segundos de señal de prueba (grave 110 Hz + agudo 3000 Hz).
   */
  function synthesizeTestSignal(fs) {
    const N = Math.floor(fs * 2.5);
    const x = new Float32Array(N);

    for (let n = 0; n < N; n++) {
      const t = n / fs;
      const env = Math.min(1, t / 0.03, (2.5 - t) / 0.05);
      x[n] = 0.3 * env * (Math.sin(2 * Math.PI * 110 * t) + Math.sin(2 * Math.PI * 3000 * t));
    }

    return x;
  }

  /**
   * Convierte un AudioBuffer multicanal a mono normalizado a pico 0.8.
   */
  function toMonoNormalized(audioBuffer) {
    const N = audioBuffer.length;
    const x = new Float32Array(N);

    for (let c = 0; c < audioBuffer.numberOfChannels; c++) {
      const data = audioBuffer.getChannelData(c);
      for (let n = 0; n < N; n++) {
        x[n] += data[n] / audioBuffer.numberOfChannels;
      }
    }

    let maxAbs = 0;
    for (const v of x) {
      maxAbs = Math.max(maxAbs, Math.abs(v));
    }
    if (maxAbs > 0) {
      for (let n = 0; n < N; n++) {
        x[n] *= 0.8 / maxAbs;
      }
    }

    return x;
  }

  /**
   * Reproduce la señal original o filtrada con el amortiguamiento ζ actual.
   */
  function play({ filtered, R, onStatus }) {
    try {
      getAudioContext();
    } catch (e) {
      onStatus("Este navegador no permite reproducir audio aquí.");
      return;
    }

    if (currentSource) {
      try {
        currentSource.stop();
      } catch (e) {
        // Ignorar si ya se detuvo
      }
    }

    const fs = ctx.sampleRate;
    const x = Float32Array.from(userAudio || synthesizeTestSignal(fs));
    const N = x.length;
    const buf = ctx.createBuffer(1, N, fs);

    if (filtered) {
      const z = R / Rcr;
      const fc = 400;
      const Ca = 1 / (L * (2 * Math.PI * fc) ** 2);
      const Ra = 2 * z * Math.sqrt(L / Ca);

      // Coeficientes del filtro IIR de 2.º orden por transformación bilineal
      const a = L * Ca;
      const b = Ra * Ca;
      const K = 2 * fs;
      const d0 = a * K * K + b * K + 1;

      const b0 = 1 / d0;
      const b1 = 2 / d0;
      const b2 = 1 / d0;
      const a1 = (2 - 2 * a * K * K) / d0;
      const a2 = (a * K * K - b * K + 1) / d0;

      let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
      for (let n = 0; n < N; n++) {
        const xn = x[n];
        const yn = b0 * xn + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
        x2 = x1;
        x1 = xn;
        y2 = y1;
        y1 = yn;
        x[n] = Math.max(-1, Math.min(1, yn));
      }

      const pct3k = (100 * gain((3000 * fn) / fc, z * Rcr)).toFixed(1);
      onStatus(
        `Filtrado con ζ = ${z.toFixed(2)}: C = ${(Ca * 1e9).toFixed(0)} nF y R = ${Ra.toFixed(0)} Ω. ` +
        `Los agudos se apagan: suena "bajo el agua". Un tono de 3000 Hz sale con ${pct3k} %.`
      );
    } else {
      onStatus("Original, sin filtrar.");
    }

    buf.copyToChannel(x, 0);
    currentSource = ctx.createBufferSource();
    currentSource.buffer = buf;
    currentSource.connect(ctx.destination);

    ctx
      .resume()
      .then(() => currentSource.start())
      .catch(() => onStatus("No se pudo reproducir el audio."));
  }

  /**
   * Decodifica un Blob o File de audio y lo deja listo para reproducir.
   */
  async function loadBlob(blob, name, { onSourceName, onStatus }) {
    try {
      const arrayBuffer = await blob.arrayBuffer();
      const audioBuffer = await getAudioContext().decodeAudioData(arrayBuffer);
      userAudio = toMonoNormalized(audioBuffer);
      onSourceName(name);
      onStatus("Listo. Dale a Original y luego a Filtrado.");
    } catch (e) {
      onStatus("No se pudo leer ese audio. Prueba con un .mp3 o .wav.");
    }
  }

  /**
   * Graba 3 segundos de voz usando el micrófono del dispositivo.
   */
  async function recordVoice({ buttonEl, onSourceName, onStatus }) {
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      onStatus(
        'El micrófono no está permitido aquí. Abre el archivo .html descargado (doble clic) y acepta el permiso, o usa "Cargar un audio".'
      );
      return;
    }

    const recorder = new MediaRecorder(stream);
    const chunks = [];

    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.onstop = () => {
      stream.getTracks().forEach((track) => track.stop());
      buttonEl.classList.remove("live");
      buttonEl.textContent = "● Grabar mi voz (3 s)";
      loadBlob(new Blob(chunks, { type: recorder.mimeType }), "tu grabación", {
        onSourceName,
        onStatus,
      });
    };

    buttonEl.classList.add("live");
    buttonEl.textContent = "Grabando… habla ahora";
    onStatus("Grabando 3 segundos.");
    recorder.start();
    setTimeout(() => recorder.stop(), 3000);
  }

  /**
   * Restaura la señal sintetizada por defecto.
   */
  function resetToSynth({ onSourceName, onStatus }) {
    userAudio = null;
    onSourceName("grave de 110 Hz + pitido de 3000 Hz");
    onStatus("Sonido de prueba listo.");
  }

  RLC.audio = {
    play,
    loadBlob,
    recordVoice,
    resetToSynth,
  };
})(window);
